import config_pkg::*;

module tb_cnn();

    // Testbench Signals
    logic clk;
    logic reset;
    logic start;
    logic valid_in;
    logic signed [PIXEL_WIDTH-1:0] pixel_in;
    
    logic signed [PIXEL_WIDTH-1:0] pixel_out;
    logic valid_out;

    // Instantiate your Top-Level Accelerator
    cnn_accelerator_top dut (
        .clk(clk),
        .reset(reset),
        .start(start),
        .valid_in(valid_in),
        .pixel_in(pixel_in),
        .pixel_out(pixel_out),
        .valid_out(valid_out)
    );

    // Generate a 10ns Clock (100 MHz)
    always #5 clk = ~clk;

    // Create a tiny 5x5 mock image (A bright square in the middle of a dark background)
    logic signed [PIXEL_WIDTH-1:0] test_image [0:24] = '{
        10, 10,  10, 10, 10,
        10, 50,  50, 50, 10,
        10, 50, 120, 50, 10,
        10, 50,  50, 50, 10,
        10, 10,  10, 10, 10
    };

    integer i;

    // Run the Simulation
    initial begin
        // 1. Initialize Everything
        clk = 0;
        reset = 1;
        start = 0;
        valid_in = 0;
        pixel_in = 0;

        // 2. Release Reset and Wake Up the FSM
        #20 reset = 0;
        #10 start = 1;
        #10 start = 0;

        // 3. Stream the 5x5 image into the Line Buffers
        for (i = 0; i < 25; i = i + 1) begin
            @(posedge clk);
            valid_in = 1'b1;
            pixel_in = test_image[i];
        end

        // 4. Stop sending data
        @(posedge clk);
        valid_in = 1'b0;

        // 5. Wait for the final pixels to flush through the MAC and ReLU pipeline
        #200;

        // 6. End Simulation
        $display("CNN Hardware Simulation Complete!");
        $finish;
    end

endmodule