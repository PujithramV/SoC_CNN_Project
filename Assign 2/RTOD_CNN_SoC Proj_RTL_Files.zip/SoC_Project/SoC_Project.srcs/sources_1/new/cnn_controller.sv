module cnn_controller (
    input  logic clk,
    input  logic reset,
    
    // Signals from the Top Level / ARM Processor
    input  logic start,       // Tells the accelerator to wake up
    
    // Signals from Satvik's Memory Modules
    input  logic window_valid, // High when the 3x3 buffer is fully loaded
    
    // Control signals to YOUR Datapath
    output logic en_mac,
    output logic en_relu,
    output logic en_pool
);

    // Define the States
    typedef enum logic [1:0] {
        IDLE        = 2'b00,
        BUFFER_FILL = 2'b01,
        CONV_STREAM = 2'b10
    } state_t;

    state_t current_state, next_state;

    // State Register (Sequential)
    always_ff @(posedge clk or posedge reset) begin
        if (reset)
            current_state <= IDLE;
        else
            current_state <= next_state;
    end

    // Next State Logic (Combinational)
    always_comb begin
        // Default assignment to prevent latches
        next_state = current_state;
        
        case (current_state)
            IDLE: begin
                if (start) 
                    next_state = BUFFER_FILL;
            end
            
            BUFFER_FILL: begin
                // Wait here until Satvik's window generator says the 3x3 grid is ready
                if (window_valid)
                    next_state = CONV_STREAM;
            end
            
            CONV_STREAM: begin
                // The pipeline is running. If valid drops, wait for more data.
                // For this assignment, we'll assume a continuous stream until reset.
                if (!window_valid)
                    next_state = BUFFER_FILL;
            end
            
            default: next_state = IDLE;
        endcase
    end

    // Output Logic (Combinational)
    always_comb begin
        // Default all to zero
        en_mac  = 1'b0;
        en_relu = 1'b0;
        en_pool = 1'b0;
        
        case (current_state)
            CONV_STREAM: begin
                // When streaming, turn on the entire math pipeline!
                // The individual valid_in signals between your modules will handle the data safety.
                en_mac  = 1'b1;
                en_relu = 1'b1;
                en_pool = 1'b1;
            end
        endcase
    end

endmodule