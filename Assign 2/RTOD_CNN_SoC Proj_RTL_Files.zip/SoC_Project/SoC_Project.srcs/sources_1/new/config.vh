package config_pkg;
    localparam PIXEL_WIDTH = 8;
    localparam WEIGHT_WIDTH = 8;
    localparam ACCUM_WIDTH = 32;
    localparam IMG_WIDTH = 32;
    localparam IMG_HEIGHT = 32;
endpackage