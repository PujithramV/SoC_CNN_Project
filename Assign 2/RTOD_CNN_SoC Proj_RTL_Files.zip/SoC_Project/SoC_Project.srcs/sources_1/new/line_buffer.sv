import config_pkg::*;

module line_buffer (
    input  logic clk,
    input  logic rst,
    input  logic valid_in,
    input  logic signed [PIXEL_WIDTH-1:0] pixel_in,

    output logic signed [PIXEL_WIDTH-1:0] line1_out,
    output logic signed [PIXEL_WIDTH-1:0] line2_out
);

    logic signed [PIXEL_WIDTH-1:0] line1 [0:IMG_WIDTH-1];
    logic signed [PIXEL_WIDTH-1:0] line2 [0:IMG_WIDTH-1];
    logic [$clog2(IMG_WIDTH)-1:0] col;

    always_ff @(posedge clk) begin
        if (rst) begin
            col <= 0;
        end else if (valid_in) begin
            line2[col] <= line1[col];
            line1[col] <= pixel_in;

            line1_out <= line1[col];
            line2_out <= line2[col];

            col <= (col == IMG_WIDTH-1) ? 0 : col + 1;
        end
    end
endmodule