import config_pkg::*;

module relu_activation (
    input  logic clk,
    input  logic reset,
    input  logic en_relu,
    
    // Grabbing the 32-bit output from your MAC array
    input  logic signed [ACCUM_WIDTH-1:0] mac_in,
    input  logic                          valid_in,

    // Sending an 8-bit output to the Pooling layer
    output logic signed [PIXEL_WIDTH-1:0] relu_out,
    output logic                          valid_out
);

    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            relu_out  <= '0;
            valid_out <= 1'b0;
        end else if (en_relu && valid_in) begin
            
            // Check the sign bit (MSB). For 32-bit, it is bit 31.
            if (mac_in[ACCUM_WIDTH-1] == 1'b1) begin
                // The number is negative -> Output 0
                relu_out <= '0;
                
            end else begin
                // The number is positive. 
                // We must saturate it if it exceeds the 8-bit signed maximum (127).
                if (mac_in > 32'sd127) begin
                    relu_out <= 8'sd127; // Clamp to max positive
                end else begin
                    relu_out <= mac_in[PIXEL_WIDTH-1:0]; // Safe to truncate
                end
            end
            
            valid_out <= 1'b1; // Tell the pooling layer data is ready
        end else begin
            valid_out <= 1'b0;
        end
    end

endmodule