import config_pkg::*;

module max_pool_2x2 (
    input  logic clk,
    input  logic reset,
    input  logic en_pool,
    input  logic valid_in,
    
    // Taking 4 pixels from a 2x2 window (output from the ReLU block)
    input  logic signed [PIXEL_WIDTH-1:0] pool_in [0:3], 
    
    // Outputting the single maximum pixel
    output logic signed [PIXEL_WIDTH-1:0] pool_out,
    output logic                          valid_out
);

    logic signed [PIXEL_WIDTH-1:0] max_1, max_2;

    // We use a synchronous block so it stays perfectly aligned with our pipeline
    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            pool_out  <= '0;
            valid_out <= 1'b0;
        end else if (en_pool && valid_in) begin
            
            // Compare the first row
            max_1 = (pool_in[0] > pool_in[1]) ? pool_in[0] : pool_in[1];
            
            // Compare the second row
            max_2 = (pool_in[2] > pool_in[3]) ? pool_in[2] : pool_in[3];
            
            // Final comparison to find the absolute maximum of the 2x2 grid
            pool_out <= (max_1 > max_2) ? max_1 : max_2;
            
            valid_out <= 1'b1; // Signal the FSM that pooling is complete
        end else begin
            valid_out <= 1'b0;
        end
    end

endmodule