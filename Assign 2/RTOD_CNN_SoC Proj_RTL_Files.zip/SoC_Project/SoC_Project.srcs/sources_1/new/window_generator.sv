import config_pkg::*;

module window_generator (
    input  logic clk,
    input  logic rst,
    input  logic valid_in,

    input  logic signed [PIXEL_WIDTH-1:0] pixel_in,
    input  logic signed [PIXEL_WIDTH-1:0] line1_in,
    input  logic signed [PIXEL_WIDTH-1:0] line2_in,

    output logic valid_out,
    output logic signed [PIXEL_WIDTH-1:0] window_pixels [0:8]
);

    logic signed [PIXEL_WIDTH-1:0] shift0 [0:2];
    logic signed [PIXEL_WIDTH-1:0] shift1 [0:2];
    logic signed [PIXEL_WIDTH-1:0] shift2 [0:2];
    integer i;

    logic [$clog2(IMG_WIDTH*2 + 5):0] valid_cnt; 

    always_ff @(posedge clk) begin
        if (rst) begin
            valid_out <= 0;
            valid_cnt <= 0;
        end else if (valid_in) begin
            
            for (i = 2; i > 0; i--) begin
                shift0[i] <= shift0[i-1];
                shift1[i] <= shift1[i-1];
                shift2[i] <= shift2[i-1];
            end

            shift0[0] <= pixel_in;
            shift1[0] <= line1_in;
            shift2[0] <= line2_in;

            window_pixels[0] <= shift2[2]; window_pixels[1] <= shift2[1]; window_pixels[2] <= shift2[0];
            window_pixels[3] <= shift1[2]; window_pixels[4] <= shift1[1]; window_pixels[5] <= shift1[0];
            window_pixels[6] <= shift0[2]; window_pixels[7] <= shift0[1]; window_pixels[8] <= shift0[0];

            if (valid_cnt < (IMG_WIDTH * 2) + 3)
                valid_cnt <= valid_cnt + 1;

            valid_out <= (valid_cnt >= (IMG_WIDTH * 2) + 2);
        end
    end
endmodule