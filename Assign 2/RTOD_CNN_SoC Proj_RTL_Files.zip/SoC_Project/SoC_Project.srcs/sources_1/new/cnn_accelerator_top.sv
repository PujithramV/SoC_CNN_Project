import config_pkg::*;

module cnn_accelerator_top (
    input  logic clk,
    input  logic reset,
    input  logic start,
    
    // Input Stream (From the Testbench)
    input  logic                          valid_in,
    input  logic signed [PIXEL_WIDTH-1:0] pixel_in,
    
    // Output Stream (To the Testbench)
    output logic signed [PIXEL_WIDTH-1:0] pixel_out,
    output logic                          valid_out
);

    // --- INTERNAL WIRES ---
    logic window_valid;
    logic signed [PIXEL_WIDTH-1:0] window_pixels [0:8];
    // Hardcoding simple edge-detection weights for tonight's simulation
    logic signed [WEIGHT_WIDTH-1:0] weights [0:8] = '{1, 0, -1, 2, 0, -2, 1, 0, -1}; 
    
    logic signed [ACCUM_WIDTH-1:0] mac_result;
    logic mac_valid;
    logic en_mac, en_relu, en_pool;

    // --- INSTANTIATE MODULES ---

    // 1. The FSM (The Brain)
    cnn_controller controller_inst (
        .clk(clk),
        .reset(reset),
        .start(start),
        .window_valid(window_valid),
        .en_mac(en_mac),
        .en_relu(en_relu),
        .en_pool(en_pool)
    );

    // 2. Satvik's Memory
    logic signed [PIXEL_WIDTH-1:0] line1_out, line2_out;
    
    line_buffer lb_inst (
        .clk(clk), .rst(reset), .valid_in(valid_in), .pixel_in(pixel_in),
        .line1_out(line1_out), .line2_out(line2_out)
    );

    window_generator wg_inst (
        .clk(clk), .rst(reset), .valid_in(valid_in), 
        .pixel_in(pixel_in), .line1_in(line1_out), .line2_in(line2_out),
        .valid_out(window_valid), .window_pixels(window_pixels)
    );

    // 3. Your Math Engine
    mac_array_3x3 mac_inst (
        .clk(clk), .reset(reset), .en_mac(en_mac),
        .pixels(window_pixels), .weights(weights),
        .mac_out(mac_result), .valid_out(mac_valid)
    );

    // 4. Your Activation Layer
    relu_activation relu_inst (
        .clk(clk), .reset(reset), .en_relu(en_relu),
        .mac_in(mac_result), .valid_in(mac_valid),
        .relu_out(pixel_out), .valid_out(valid_out)
    );

endmodule