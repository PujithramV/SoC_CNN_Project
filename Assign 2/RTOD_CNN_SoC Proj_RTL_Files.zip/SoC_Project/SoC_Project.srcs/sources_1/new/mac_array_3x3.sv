import config_pkg::*; // This replaces the `include!

module mac_array_3x3 (
    input  logic clk,
    input  logic reset,
    input  logic en_mac,
    
    input  logic signed [PIXEL_WIDTH-1:0]  pixels  [0:8], 
    input  logic signed [WEIGHT_WIDTH-1:0] weights [0:8],
    
    output logic signed [ACCUM_WIDTH-1:0]  mac_out,
    output logic                           valid_out
);

    logic signed [15:0] products [0:8];
    integer i;

    // Parallel Combinational Multiplication
    always_comb begin
        for (i = 0; i < 9; i = i + 1) begin
            products[i] = pixels[i] * weights[i];
        end
    end

    // Synchronous Accumulator
    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            mac_out   <= '0;
            valid_out <= 1'b0;
        end else if (en_mac) begin
            mac_out <= products[0] + products[1] + products[2] + 
                       products[3] + products[4] + products[5] + 
                       products[6] + products[7] + products[8];
            valid_out <= 1'b1; 
        end else begin
            valid_out <= 1'b0; 
        end
    end

endmodule